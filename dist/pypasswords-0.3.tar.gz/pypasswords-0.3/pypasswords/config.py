numbers = '1234567890'
letters = 'qwertyuiopasdfghjklzxcvbnm\
QWERTYUIOPASDFGHJKLZXCVBNM'
symbols = '!@#$%^&*()-=_+|,./<>?;:"[]{}'

salt_dictionary = numbers + letters + symbols
