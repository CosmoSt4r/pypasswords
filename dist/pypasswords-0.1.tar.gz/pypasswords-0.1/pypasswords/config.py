sault_dictionary = '1234567890\
qwertyuiopasdfghjklzxcvbnm\
QWERTYUIOPASDFGHJKLZXCVBNM\
!@#$%^&*()-=_+|,./<>?;:"[]{}'
